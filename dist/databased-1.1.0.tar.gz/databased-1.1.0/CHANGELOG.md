# Changelog

## 1.0.6 (2023-03-03)

#### Refactorings

* change return type to list
#### Others

* update readme


## v1.0.5 (2023-02-04)

#### Others

* update to build v1.0.5
* add files